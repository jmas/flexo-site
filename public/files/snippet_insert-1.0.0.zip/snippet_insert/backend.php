<?php if (!defined('CMS_ROOT')) die;

Plugin::addController('snippet_insert', 'snippet_insert', array('developer','administrator'));