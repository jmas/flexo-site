<?php if (!defined('CMS_ROOT')) die;

return array(
    'Pages Scheduler' => 'Расписание публикаций',
);