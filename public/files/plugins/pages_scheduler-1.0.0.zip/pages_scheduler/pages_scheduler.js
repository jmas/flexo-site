// Assing this script when schedule calendar index page requested
cms.init.add(['plugin_pages_scheduler_index'], function()
{   
    $('#calendar').fullCalendar({
        header: {
            left: 'prev,next today',
            center: 'title',
            right: 'month,agendaWeek,agendaDay'
        },
        editable: false,
        events: function(start, end, callback) {
            $.ajax({
                url: BASE_URL + ADMIN_DIR_NAME + '/plugin/pages_scheduler/feed',
                dataType: 'json',
                data: {
                    // our hypothetical feed requires UNIX timestamps
                    start: Math.round(start.getTime() / 1000),
                    end: Math.round(end.getTime() / 1000)
                },
                success: function(result) {
                    var events = [];
                    $(result).each(function(i, item) {
                        events.push({
                            title: item.title,
                            start: new Date(item.start * 1000),
                            url: item.url,
                            allDay: false
                        });
                        console.log(new Date(item.start * 1000));
                    });
                    callback(events);
                }
            });
        }
    });
}); // end