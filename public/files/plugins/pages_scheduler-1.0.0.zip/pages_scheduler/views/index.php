<h1>
	<?php echo __('Pages Scheduler'); ?>
</h1>

<div id="calendar"></div>