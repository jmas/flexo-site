<?php if(!defined('CMS_ROOT')) die;

return array(
	'Captcha image have different text. Please retype captcha!'
	                                        => 'Текст на рисунке отличается от того, что вы ввели. Пожалуйста, повторите ввод!',
											
	'Type text that present on this image.' => 'Напишите текст, который представлен на этой картинке.',
	'Image text' => 'Текст с картинки',
	'Captcha settings' => 'Настройки каптчи',
	'Where you want use captcha?' => 'Где желаете использовать каптчу?',
	'Protect login form' => 'Защитить форму входа',
	'Captcha will be displayed at login and forgot password pages.' => 'Каптча будет отображаться при входе и восстановлении пароля.',
	'Yes' => 'Да',
	'No' => 'Нет'
);