<?php if (!defined('CMS_ROOT')) die;

return array(
	'Add images' => 'Добавить изображения'
);